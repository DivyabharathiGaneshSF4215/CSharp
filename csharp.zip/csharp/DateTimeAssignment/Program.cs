﻿using System;
namespace DateTimeAssignment;
class Program
{
    public static void Main(string[] args)
    {
        DateTime date = DateTime.Today;
        
        // To print the current month of the day
        int month = date.Month;
        Console.WriteLine("The current month of the day is :"+month);

        // To print the previous of 3 day from current date
        Console.WriteLine("The previous of 3 days from current date is :"+date.AddDays(-3));

        // To print the 12 hours’ time of now followed by am , pm
        Console.WriteLine("The 12 hours' time of now followed by am, pm: "+DateTime.UtcNow);

    }
}





