﻿using System;
namespace ForLoopAssignment;
class Program
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Enter ten numbers: ");
        int[] number = new int[10];
        int sum=0;
        double average =0;

        for(int i=0;i<number.Length;i++)
        {
            number[i] = int.Parse(Console.ReadLine());
            sum = sum + number[i];
        }
        average = sum /10;
        
        Console.WriteLine("Sum of given ten numbers is : "+sum);
        Console.WriteLine("Average of given numbers is : "+average);
    }
}
