﻿using System;
namespace WhileAssignment;
class Program
{
    public static void Main(string[] args)
    {
        //assign a variable for check the user's wish to continue or not
        char check = 'Y';
        while (check == 'Y')
        {
            //display the information 
            Console.WriteLine("Which city is capital of India? ");
            Console.WriteLine("1.Chennai\n2.Delhi\n3.Mumbai\n4.Kolkata\n");

            //get input from the user
            Console.WriteLine("Enter your choice:");
            int choice = int.Parse(Console.ReadLine());
            //Check whether the choice is correct or not!
            if (choice == 2)
            {
                Console.WriteLine("Correct");
            }
            else
            {
                Console.WriteLine("Incorrect!");
            }
            // Press Y to continue, Press N to close
            Console.WriteLine("Do you want to continue ?(Y/N):");
            check = char.Parse(Console.ReadLine().ToUpper());

        }
       
    }
}
