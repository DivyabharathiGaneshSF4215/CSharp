﻿using System;
using System.Xml.XPath;
namespace StringAssignment;
class Program
{
    public static void Main(string[] args)
    {
        string inputString = "Syncfusion";
        char[] stringToArray = inputString.ToCharArray();

        // Display the odd number of characters from above string.
        for(int i=0;i< stringToArray.Length;i++)
        {
            if(i%2 ==0)
            {
                Console.Write(stringToArray[i]);
            }
        }
        // Replace the character n with capital N
        Console.WriteLine();
        for(int i=0;i< stringToArray.Length;i++)
        {
            if(stringToArray[i] == 'n')
            {
                stringToArray[i] = 'N';
            }
        }
        foreach(char ch in stringToArray)
        {
            Console.Write(ch);
        }
        Console.WriteLine();

        // Display the above string in reverse
        Console.Write("The given string in reverse is: ");
        for(int i = inputString.Length-1;i >=0;i--)
        {
            Console.Write(inputString[i]);
        }

        // Calculate the length of above string
        Console.WriteLine();
        int lengthOfString = 0;
        foreach(char ch in inputString)
        {
            lengthOfString +=1;
        }
        Console.WriteLine("Length of the given string is: "+lengthOfString);

        
        // Get the two string from user and concatenate the first 4 characters of first string and last 3 characters of second string
        Console.WriteLine("Enter two strings: ");
        string userInput1 = Console.ReadLine();
        string userInput2 = Console.ReadLine();
        string result = "";
        for(int i=0;i<4;i++)
        {
            result += userInput1[i].ToString();
        }
        for (int i = userInput2.Length-3 ;i<= userInput2.Length-1;i++)
        {
            result += userInput2[i].ToString();
        }
        Console.WriteLine("The resultant string is :"+result);
        Console.WriteLine();

        //Print the words by splitting with comma and print in separate line
        string words ="Chennai,Trichy,Mumbai";
        string[] resultantString = words.Split(",");
        Console.WriteLine("Words by splitting with comma:");
        foreach(string s in resultantString)
        {
            Console.WriteLine(s);
        }
        
    } 

}

