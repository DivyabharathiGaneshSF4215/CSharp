﻿using System;
namespace IfElseAssignment;
class Program
{
    public static void Main(string[] args)
    {
        char grade;
        bool check;
        do{
            Console.WriteLine("Enter your Grade : ");
            check = char.TryParse(Console.ReadLine().ToUpper(),out grade);
            if(!check)
            {
                Console.WriteLine("Invalid Grade try again...!");
            }
        }while(!check);
        if(grade == 'A')
        {
            Console.WriteLine("Grade A denotes 9 points");
        }
        else if(grade == 'B')
        {
            Console.WriteLine("Grade B denotes 8 points");
        }
        else if(grade == 'C')
        {
            Console.WriteLine("Grade C denotes 7 points");
        }
        else if(grade == 'D')
        {
            Console.WriteLine("Grade D denotes 6 points");
        }
        else 
        {
            Console.WriteLine("This is not a valid grade");
        }
    }
}