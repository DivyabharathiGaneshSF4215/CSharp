﻿using System;
namespace OperatorsAssignment_1;
class Program
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Enter first number:");
        double number1 = double.Parse(Console.ReadLine());
        Console.WriteLine("Enter second number: ");
        double number2 = double.Parse(Console.ReadLine());

        Console.WriteLine("Addition result is: " + (number1 + number2));
        Console.WriteLine("Subraction result is: " + (number1 - number2));
        Console.WriteLine("Multiplication result is: " + (number1 * number2));
        Console.WriteLine("Division result is: " + (number1 / number2));
        Console.WriteLine("Modulo Division result is: " + (number1 % number2));
        
        //method for finding largest numbers
        Largest();


    }
    public static void Largest()
    {
        Console.WriteLine("Enter three numbers: ");
        double number1 = double.Parse(Console.ReadLine());
        double number2 = double.Parse(Console.ReadLine());
        double number3 = double.Parse(Console.ReadLine());

        double largest = number1 > number2 && number1 > number3 ? number1 : (number2 > number1 && number2 > number3) ? number2 : number3;
        Console.WriteLine("The largest number is : " + largest);
    }
}
